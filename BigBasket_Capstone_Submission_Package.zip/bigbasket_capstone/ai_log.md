# AI-Assisted Prompting Log

## Prompt 1 — SQL (RCTCF)

**Role:** You are a SQL analyst working on a deterministic BigBasket category-performance diagnostic in SQLite.

**Context:** The database is `bigbasket_capstone.db` with `orders`, `products`, and `category_targets` tables. Delivered orders should be used for revenue reporting. The monthly report must use SQLite `strftime('%Y-%m', order_date)`.

**Task:** Draft/debug a SQL query that joins `orders` to `products`, groups Delivered orders by category and month, and returns `category, month, order_count, total_revenue, avg_revenue`.

**Constraints:** Use SQLite syntax; do not modify source data; group by category and month; use only Delivered orders; preserve exact integer revenue totals; use `strftime` for the month.

**Format:** Return one runnable SQL query followed by a short explanation of the key clauses.

**Verification actually performed:** I ran the final query against `bigbasket_capstone.db`, confirmed it returned **36 rows (6 categories × 6 months)**, and checked that the summed `total_revenue` was exactly **88282**.

## Prompt 2 — Pandas (RCTCF)

**Role:** You are a Pandas data-cleaning analyst helping validate an order-revenue dataset.

**Context:** `orders_raw.csv` contains duplicate order IDs, mixed casing/whitespace, missing `amount_inr` values, and unusually large Delivered amounts. Missing revenue must be excluded from revenue calculations. Rating nulls for Cancelled/Pending orders are legitimate.

**Task:** Explain/debug the Pandas IQR outlier workflow: calculate Q1 and Q3 on Delivered non-null `amount_inr`, calculate the upper fence as `Q3 + 1.5*IQR`, and cap values above that fence without dropping rows.

**Constraints:** Use `.quantile()` and `.clip(upper=...)`; do not replace missing revenue with zero or mean; do not fill legitimate rating nulls.

**Format:** Provide the concise Pandas code and explain how to verify the number of capped rows.

**Verification actually performed:** I re-ran the cleaning workflow on `orders_raw.csv`, obtained **Q1 = 90.0, Q3 = 275.0, upper fence = 552.5**, and confirmed **16 Delivered rows** were above the fence and therefore capped at 552.5.
