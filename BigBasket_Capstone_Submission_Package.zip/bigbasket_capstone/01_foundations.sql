-- 01_foundations.sql
-- Each query is labelled to demonstrate the required SQL concepts.

-- 1. SELECT / WHERE: orders from Mumbai
SELECT * FROM orders
WHERE customer_id IN (SELECT customer_id FROM customers WHERE city = 'Mumbai');

-- 2. DISTINCT: every distinct category
SELECT DISTINCT category
FROM products
ORDER BY category;

-- 3. ORDER BY + LIMIT: 5 highest-value orders
SELECT order_id, amount_inr
FROM orders
ORDER BY amount_inr DESC
LIMIT 5;

-- 4. Alias (AS): aggregate alias
SELECT COUNT(*) AS total_orders
FROM orders;

-- 5. IN: orders paid using UPI or Credit Card
SELECT *
FROM orders
WHERE payment_mode IN ('UPI', 'Credit Card');

-- 6. BETWEEN: orders with amount between INR 100 and INR 300
SELECT *
FROM orders
WHERE amount_inr BETWEEN 100 AND 300;

-- 7. NOT BETWEEN: orders outside INR 100 to INR 300
SELECT *
FROM orders
WHERE amount_inr NOT BETWEEN 100 AND 300;

-- 8. IS NULL: orders with no rating
SELECT *
FROM orders
WHERE rating IS NULL;
