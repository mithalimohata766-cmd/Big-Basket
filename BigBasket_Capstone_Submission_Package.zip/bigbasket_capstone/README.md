# BigBasket Category Performance Diagnostic

## Project overview
This project builds one deterministic BigBasket-style dataset and uses the same clean monthly revenue export across SQLite SQL, a spreadsheet cross-check, Tableau Public, and an independent Pandas cleaning workflow. The goal is to identify categories that are above/below revenue targets, prove that the SQL totals survive into the spreadsheet and Tableau input unchanged, and independently confirm the top category and supplier from messy raw data.

## Repository structure

```text
bigbasket_capstone/
├── generate_data.py
├── bigbasket_capstone.db
├── orders_raw.csv
├── products.csv
├── verify.sql
├── 01_foundations.sql
├── 02_aggregation_joins.sql
├── 03_reporting.sql
├── monthly_category_revenue.csv
├── BigBasket_Category_Cross_Check.xlsx
├── analysis.ipynb
├── ai_log.md
└── README.md
```

## Part 1 — SQL

Run the deterministic generator exactly as supplied:

```bash
python3 generate_data.py
```

It creates `bigbasket_capstone.db`, `orders_raw.csv`, and `products.csv`.

Verification:
- Products: 31
- Customers: 50
- Orders: 500
- Category targets: 6
- Delivered: 434
- Cancelled: 42
- Pending: 24

SQL task files:
- `01_foundations.sql` — SELECT/WHERE, DISTINCT, ORDER BY + LIMIT, AS, IN, BETWEEN, NOT BETWEEN, IS NULL.
- `02_aggregation_joins.sql` — INNER JOIN aggregation with HAVING and LEFT JOIN product-order counts.
- `03_reporting.sql` — CASE tiering, monthly category report, and target variance report.
- `monthly_category_revenue.csv` — direct, unmodified export of the monthly-by-category Delivered revenue query.

The CSV contains 36 data rows and the grand total Delivered revenue is INR 88,282.

## Part 2 — Spreadsheet cross-check

Workbook: `BigBasket_Category_Cross_Check.xlsx`

Sheets:
1. `Monthly Data` — exact CSV import.
2. `Category Targets` — the six fixed target values.
3. `Pivot Table` — category-level revenue and order-count aggregation.
4. `Category Summary` — pivot-referenced totals, XLOOKUP targets, variance, percentage variance, three-tier status, and reconciliation.

Expected category totals from Part 1:
| Category | SQL total (INR) | Target (INR) | Status |
|---|---:|---:|---|
| Household Essentials | 21,715 | 17,000 | Above Target |
| Personal Care | 16,382 | 15,500 | Above Target |
| Bakery | 15,410 | 12,000 | Above Target |
| Dairy & Eggs | 14,090 | 16,500 | Below Target - Watch |
| Snacks & Beverages | 10,895 | 13,000 | Below Target - Critical |
| Fruits & Vegetables | 9,790 | 12,000 | Below Target - Critical |

## Part 3 — Tableau Public

**Live Tableau Public dashboard:** `PASTE YOUR LIVE TABLEAU PUBLIC URL HERE`

The dashboard should contain:
- Monthly Delivered revenue trend for Jan–Jun 2026.
- Descending category revenue bar chart with the three target-status tiers.
- KPI cards for Total Revenue, Total Delivered Orders, Average Order Value, and Categories Meeting Target.
- A dashboard-wide interactive filter with its legend visible.

### Data story

**Above Target**
- Household Essentials: INR 21,715, which is INR 4,715 above its INR 17,000 target.
- Personal Care: INR 16,382, which is INR 882 above its INR 15,500 target.
- Bakery: INR 15,410, which is INR 3,410 above its INR 12,000 target.

**Below Target**
- Dairy & Eggs: INR 14,090, a shortfall of INR 2,410 (14.61%), so it is **Below Target - Watch**.
- Snacks & Beverages: INR 10,895, a shortfall of INR 2,105 (16.19%), so it is **Below Target - Critical**.
- Fruits & Vegetables: INR 9,790, a shortfall of INR 2,210 (18.42%), so it is **Below Target - Critical**.

### Two recommendations

1. **Prioritize catalog and marketing effort for Household Essentials.** It is the highest-revenue category at INR 21,715 and exceeds its target by INR 4,715.
2. **Review the Snacks & Beverages and Fruits & Vegetables categories for corrective action.** They are the two Critical categories, with shortfalls of INR 2,105 and INR 2,210 respectively.

## Part 4 — Python/Pandas

Notebook: `analysis.ipynb`

The notebook:
- Loads and inspects both raw CSVs.
- Removes 8 duplicate order rows, returning the dataset to 500 orders.
- Normalizes city/category casing and whitespace.
- Counts 10 missing revenue values and excludes them from revenue calculations.
- Leaves legitimate Cancelled/Pending rating nulls unchanged.
- Computes IQR outlier thresholds on Delivered non-null revenue:
  - Q1 = 90.0
  - Q3 = 275.0
  - IQR = 185.0
  - Upper fence = 552.5
  - Rows capped = 16
- Creates date/derived fields.
- Merges orders with products to analyze supplier revenue.
- Confirms the top category is **Household Essentials** and the top supplier is **HomeEssentials Traders**, matching Part 1.
- Includes three matplotlib charts and exactly three What / Why it matters / Next step observations.

Post-cleaning/capping category revenue:
- Household Essentials: INR 20,910
- Bakery: INR 14,975
- Personal Care: INR 14,594.50
- Dairy & Eggs: INR 13,675
- Snacks & Beverages: INR 11,312.50
- Fruits & Vegetables: INR 9,170

## AI-assisted prompting log

See `ai_log.md` for both required RCTCF prompts and the concrete verification steps performed for the SQL and Pandas work.

## Final submission

The assignment requires **exactly one submission: the public GitHub repository link**. After creating the public repository and committing every file listed above, submit only that GitHub repository URL.

Before submission, replace the Tableau placeholder above with the actual public Tableau Public dashboard URL.
